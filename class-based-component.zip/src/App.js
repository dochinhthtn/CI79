import TodoApp from "./components/TodoApp";

function App() {
  return (
    <div className="App">
      <TodoApp name="Todo App 1" owner="Chinh Do" createdAt="2023/02/12" />
    </div>
  );
}

export default App;
